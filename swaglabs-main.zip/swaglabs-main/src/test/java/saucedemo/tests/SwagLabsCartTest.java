package saucedemo.tests;

public class SwagLabsCartTest {
	

}
